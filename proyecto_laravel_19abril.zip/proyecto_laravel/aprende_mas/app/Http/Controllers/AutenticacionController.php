<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User; 
use App\Models\RegistroModels; 
use DateTime;
use Auth;
use Carbon\Carbon;
use Illuminate\Support\Str; 
use Illuminate\Support\Facades\File; 
use Illuminate\Support\Facades\Response; 

class AutenticacionController extends Controller
{
    public function registro1(Request $request) //Registro de usuario
    {
        $actual = new DateTime(); 

        $imagen = $request->file('foto');
        $extension = $imagen->extension();
        $nombreImagen = Str::slug($request->usuario) . "." . $extension;


        $data = array(
            'nombre_registro' => $request->nombre_registro,
            'apellido_registro' => $request->apellido_registro,
            'nie' => $request->nie,
            'foto' => $nombreImagen,
            'correo' => $request->correo,
            'contra' => bcrypt($request->contra), 
            'repetir_contra' => bcrypt($request->contra),

            "fecha_registro" => (new DateTime())->format("Y-m-d"),
            "estado_registro" => 1
        );


       $imagen->storeAs('fotos-perfil/', $nombreImagen);


        $nuevoAlumno = new User($data);
        $nuevoAlumno->save();

        $mensaje = array( 
            'mensaje' => "Usuario registrado correctamente"
        );

        return response()->json($mensaje);
    }
//-------------------------------------------------------------------------------------------- 
    public function registro2(Request $request) //Registro de administrador
    {
        $actual = new DateTime(); 

        $imagen = $request->file('foto');
        $extension = $imagen->extension();
        $nombreImagen = Str::slug($request->usuario) . "." . $extension;


        $data = array( 
            'nombre_registro' => $request->nombre_registro,
            'apellido_registro' => $request->apellido_registro,
            'foto' => $nombreImagen,
            'correo' => $request->correo,
            'contra' => bcrypt($request->contra), 
            'repetir_contra' => bcrypt($request->contra),
            'estado_registro' => 1,
        );


        $imagen->storeAs('fotos-perfil/', $nombreImagen);


        $nuevoAdmnistrador = new User($data);
        $nuevoAdmnistrador->save();

        $mensaje = array( 
            'mensaje' => "Usuario registrado correctamente"
        );

        return response()->json($mensaje);
    }
//--------------------------------------------------------------------------------------------
    public function iniciarSesion1(Request $request,) //Iniciar sesión para usuario
    {
     
        $credenciales = $request->only(['nie', 'contra']);

        if (Auth::attempt($credenciales) == false)
        {
        $mensaje = array(
            'mensaje' => "Verifique sus credenciales"
        );

        return response()->json($mensaje, 401);
        }

        $usuario = $request->user();

        $generarToken = $usuario->createToken('Student Access Token');
    

        $token = $generarToken->token;
        $token->save(); 
    
        $respuesta = array(
            'token_acceso' => $generarToken->accessToken,
            'tipo_token' => 'Bearer',
            'fecha_expiracion' => $generarToken->token->expires_at,
        );

        return response()->json($respuesta);
    }
//--------------------------------------------------------------------------------------------
    public function iniciarSesion2(Request $request) // Iniciar sesión para administrador
    {
        //Pedir ayuda porque da error debido a que el campo "correo" se encuentra en otra tabla y no en la misma que "contra"
        $credenciales = request(['correo', 'contra']);


        if (Auth::attempt($credenciales) == false)
        {
        $mensaje = array(
            'mensaje' => "Verifique sus credenciales"
        );

        return response()->json($mensaje, 401);
        }

        $usuario = $request->user();

        $generarToken = $usuario->createToken('Admin Access Token');
    

        $token = $generarToken->token;
        $token->save(); 
    
        $respuesta = array(
            'token_acceso' => $generarToken->accessToken,
            'tipo_token' => 'Bearer',
            'fecha_expiracion' => $generarToken->token->expires_at,
        );

        return response()->json($respuesta);
    }
//--------------------------------------------------------------------------------------------
    public function perfil1(Request $request) //Preguntar si hay alguna forma de seleccionar los datos que queremos se muestre en este campo
    //Mostrar fotos del perfil de alumno
    {
        $informacion = $request->user(); 

        return response()->json($informacion);
    }
//--------------------------------------------------------------------------------------------
    public function perfil2(Request $request) //Perfil de administrador
    {
        $informacion = $request->user(); 

        return response()->json($informacion);
    }
//--------------------------------------------------------------------------------------------
    public function cerrarSesion(Request $request) //Preguntar si es necesario tener 2 cierres de sesión distintos. Uno para alumnos y otro para administradores
    {
        $informacion = $request->user();  

        $informacion->token()->revoke(); 

        $mensaje = array(
            'mensaje' => "Cierre de sesión exitoso"
        );

        return response()->json($mensaje);
    }
//--------------------------------------------------------------------------------------------
    public function verFotoPerfil($nombreImagen)
    {
        $ruta = storage_path('app/fotos-perfil/' . $nombreImagen);


        if (file_exists($ruta) == false) {
            abort(404); 
        }


        $imagen = File::get($ruta);
        $tipo = File::mimeType($ruta);


        $respuesta = Response::make($imagen, 200);
        $respuesta->header("Content-Type", $tipo);

        return $respuesta;
    }
}