<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

//Tablas involucradas: municipio, departamento
use DateTime;
use App\Models\MunicipioModels; 
use App\Models\DepartamentoModels;

class MunicipioController extends Controller
{
    //Este controlador no se utlizó
}
