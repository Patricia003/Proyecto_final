<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use DateTime;
use App\Models\UsuarioModels; 
use App\Models\RolModels;
use App\Models\Progreso_guardadoModels; 
use App\Models\RegistroModels; 


class UsuarioController extends Controller
{
    //Los métodos de las vistas de administrador están en el controlador de registro
}
