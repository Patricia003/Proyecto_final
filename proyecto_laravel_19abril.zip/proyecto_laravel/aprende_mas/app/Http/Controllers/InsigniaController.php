<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: insignia, nivel, registro
use DateTime;
use App\Models\InsigniaModels; 
use App\Models\NivelModels;
use App\Models\RegistroModels; 

class InsigniaController extends Controller
{
    //Este controlador no se utlizó
}