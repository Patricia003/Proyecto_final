<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegistroController;
use App\Http\Controllers\InstitucionController;
use App\Http\Controllers\MateriaController;
use App\Http\Controllers\EncuestaController;
use App\Http\Controllers\TemaController;
use App\Http\Controllers\CuestionarioController;
use App\Http\Controllers\PreguntaController;
use App\Http\Controllers\InsigniaController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get("/registro-listar1", [RegistroController::class, "listar1"]);
Route::get("/registro-listar2", [RegistroController::class, "listar2"]);
Route::get("/registro-listar3", [RegistroController::class, "listar3"]);
Route::get("/institucion-listar", [InstitucionController::class, "listar"]);
Route::get("/materia-listar", [MateriaController::class, "listar"]);
Route::get("/encuesta-listar", [EncuestaController::class, "listar"]);
Route::get("/tema-listar", [TemaController::class, "listar"]);
Route::get("/cuestionario-listar", [CuestionarioController::class, "listar"]);
Route::get("/pregunta-listar", [PreguntaController::class, "listar"]);
Route::get("/insignia-listar", [InsigniaController::class, "listar"]);


