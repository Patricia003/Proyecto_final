<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Progreso_guardadoModels extends Model
{
    use HasFactory;

    protected $table = "progreso_guardado"; //Tabla creada en la base de datos
    
    public $timestamps = false; // Esto desactiva las fechas automaticas. Siempre desactival o da error

    protected $fillable = [  //campo requerido para un método insert
       'entrada',
       'salida',
       'tiempo_permanencia',
    ];
}
