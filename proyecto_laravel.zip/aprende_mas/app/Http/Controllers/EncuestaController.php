<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use DateTime;

//Tablas involucradas: encuesta
use App\Models\EncuestaModels;  

class EncuestaController extends Controller
{
    public function listar(Request $request)
    {
        $encuesta = EncuestaModels::where("encuesta.estado_encuesta", "=", 1)
        ->select("encuesta.comentario","encuesta.preg_encuesta","encuesta.estado_encuesta"); //Campos a mostrar
        $encuesta = $encuesta->get();


        for ($i=0; $i < count($encuesta); $i++) //Sustituir 1 y 0 por "activo" e "inactivo"
        { 
            if ($encuesta[$i]->estado_encuesta == 1) {
                $encuesta[$i]->estado_encuesta= "activo";
            }
            else {
                $encuesta[$i]->estado_encuesta = "inactivo";
            }
        }


        return response()->json($encuesta); //Mostrar datos
    }
}
