<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: institucion, municipio, departamento
use DateTime;
use App\Models\InstitucionModels;
use App\Models\MunicipioModels;
use App\Models\Departamento; 
use App\Http\Requests\NuevaInstitucionRequest;


class InstitucionController extends Controller
{
    public function listar(Request $request)
    {
        $institucion = InstitucionModels::all();

        $institucion = DB::table('institucion') //Conexión con otras tablas
        ->join('municipio', 'institucion.id_municipio', '=', 'municipio.id_municipio') //relación municipio con tabla institucion
        ->join('departamento', 'municipio.id_departamento', '=', 'departamento.id_departamento') //relación departamento con tabla municipio
        ->select("institucion.id_institucion","institucion.nombre_inst","institucion.tipo_institucion", "municipio.nombre_municipio","departamento.nombre_departamento", "estado_institucion") //Campos a mostrar
        ->orderby("institucion.id_institucion", "asc")
        ->get();


        for ($i=0; $i < count($institucion); $i++) //Sustituir 1 y 0 por "activo" e "inactivo"
        { 
            if ($institucion[$i]->estado_institucion == 1) {
                $institucion[$i]->estado_institucion= "activo";
            }
            else {
                $institucion[$i]->estado_institucion = "inactivo";
            }
        }


        return response()->json($institucion); //Mostrar datos en pantalla
    }
    //--------------------------------------------------------------------------------------------
    public function obtener(Request $request, $id)
    {
        $institucion = DB::table('institucion') 
        

        //Conexión con otras tablas
        ->where("institucion.id_institucion", "=", $id)
        ->join('municipio', 'institucion.id_municipio', '=', 'municipio.id_municipio') //relación municipio con tabla institucion
        ->join('departamento', 'municipio.id_departamento', '=', 'departamento.id_departamento') //relación departamento con tabla municipio
        ->select("institucion.id_institucion","institucion.nombre_inst","institucion.tipo_institucion", "municipio.nombre_municipio","departamento.nombre_departamento", "estado_institucion") //Campos a mostrar //seleccionar los datos que queremos mostrar
        ->first();

        //Condición para mostrar mensaje de error si la institucion no existe
        if ($institucion == null) {
            $mensaje = array("error" => "La institucion no fue encontrada"); //Mensaje de error

            return response()->json($mensaje, 404);
        }

        //Condición para definir el estado de una institución. Sin usar 1 y 0
        if ($institucion->estado_institucion == 1) {
            $institucion->estado_institucion= "activo";
        }
        else {
            $institucion->estado_institucion = "inactivo";
        }
        

        return response()->json($institucion);
    }
//--------------------------------------------------------------------------------------------
    public function insertar(NuevaInstitucionRequest $request)
    {
        $request->validated();

        
        $datos = array(
            //Datos que debemos ingresar desde PostMan
            "nombre_inst" => $request->nombre_inst,
            "tipo_institucion" => $request->tipo_institucion,
            "id_municipio" => $request->id_municipio,

            //Datos que nosotros ingresaremos desde Laravel
            "estado_institucion" => 1,
        );


        //Crear producto y añadir la información del arreglo datos
        $nuevaInstitucion = new InstitucionModels($datos);
        $nuevaInstitucion->save();


        switch ($nuevaInstitucion->id_municipio) { //sustituir número 1 al 7 por el municipio que representa
            case 1:
                $nuevaInstitucion->id_municipio = "Chalatenango";
                break;
            case 2:
                $nuevaInstitucion->id_municipio = "Zacatecoluca";
                break;
            case 3:
                $nuevaInstitucion->id_municipio = "San Vicente";
                break;
            case 4:
                $nuevaInstitucion->id_municipio = "Cuscatlán";
                break;
            case 5:
                $nuevaInstitucion->id_municipio = "San Salvador";
                break;
            case 6:
                $nuevaInstitucion->id_municipio = "Santa Tecla";
                break;
            case 7:
                $nuevaInstitucion->id_municipio = "Sensuntepeque";
                break;
        }


        if ($nuevaInstitucion->estado_institucion == 1) {
            $nuevaInstitucion->estado_institucion = "Activo";
        }
        else {
            $nuevaInstitucion->estado_institucion = "Inactivo";
        }

        return response()->json($nuevaInstitucion);
    }
//--------------------------------------------------------------------------------------------
    public function actualizar(Request $request, $id)
    {
        $institucion=InstitucionModels::where("id_institucion", $id)->first();
        $institucion->nombre_inst = $request->nombre_inst;
        $institucion->save();

        switch ($institucion->id_municipio) { //sustituir número 1 al 7 por el municipio que representa
            case 1:
                $institucion->id_municipio = "Chalatenango";
                break;
            case 2:
                $institucion->id_municipio = "Zacatecoluca";
                break;
            case 3:
                $institucion->id_municipio = "San Vicente";
                break;
            case 4:
                $institucion->id_municipio = "Cuscatlán";
                break;
            case 5:
                $institucion->id_municipio = "San Salvador";
                break;
            case 6:
                $institucion->id_municipio = "Santa Tecla";
                break;
            case 7:
                $institucion->id_municipio = "Sensuntepeque";
                break;
        }


        if ($institucion->estado_institucion == 1) {
            $institucion->estado_institucion = "Activo";
        }
        else {
            $institucion->estado_institucion = "Inactivo";
        }

        return response()->json($institucion);
    }
//--------------------------------------------------------------------------------------------
    public function eliminar(Request $request, $id) 
    {
        $institucion = InstitucionModels::where("id_institucion", $id)->first();

        if($institucion == null){
            $mensaje = array(
                "error"=> "Institucion no encontrada."
            );

            return response()->json($mensaje, 404);
        }

        $institucion->estado_institucion = 0;
        $institucion->save();
        $borrado = array(
            "Exito"=> "La institucion fue borrada exitosamente"
        );

        return response()->json($borrado);
    }
}
