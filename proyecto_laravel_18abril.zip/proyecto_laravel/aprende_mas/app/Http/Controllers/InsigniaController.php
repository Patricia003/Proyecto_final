<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: insignia, nivel, registro
use DateTime;
use App\Models\InsigniaModels; 
use App\Models\NivelModels;
use App\Models\RegistroModels; 

class InsigniaController extends Controller
{
    public function listar(Request $request)
    {
        $insignia = InsigniaModels::where("insignia.estado_insignia", "=", 1) //Condicion
        ->select("insignia.nombre_insignia","insignia.puntos","insignia.estado_insignia"); //Campos a mostrar
        $insignia = $insignia->get();


        for ($i=0; $i < count($insignia); $i++) //Sustituir 1 y 0 por "activo" e "inactivo"
        { 
            if ($insignia[$i]->estado_insignia == 1) {
                $insignia[$i]->estado_insignia= "activo";
            }
            else {
                $insignia[$i]->estado_insignia = "inactivo";
            }
        }        
    }

}