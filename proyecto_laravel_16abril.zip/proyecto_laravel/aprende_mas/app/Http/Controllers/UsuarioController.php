<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use DateTime;
use App\Models\UsuarioModels; 
use App\Models\RolModels;
use App\Models\Progreso_guardadoModels; 
use App\Models\RegistroModels; 


class UsuarioController extends Controller
{
    public function listar(Request $request){
    
        $administrador = UsuarioModels::all();

        $administrador = DB::table('registro') 
        ->where("rol.id", "=", 2)
       ->join()
        ->select("registro.foto","registro.nombre_registro","registro.apellido_registro", "registro.correo","registro.visitas","registro.sesiones", "regiatro.estado_registro") //Campos a mostrar
        ->get();


        for ($i=0; $i < count($registro); $i++) //Sustituir 1 y 0 por "activo" e "inactivo"
        { 
            if ($administrador[$i]->estado_registro == 1) {
                $administrador[$i]->estado_registro= "activo";
            }
            else {
                $administrador[$i]->estado_registro = "inactivo";
            }
        }


        return response()->json($administrador); //Mostrar datos en pantalla
    }
//------------------------------------------------------
    public function insertar(NuevoAdministradooRequest $request)
    {
        $request->validated();

        $datos = array(
            //Datos que debemos ingresar desde PostMan
            "nombre_usuario" => $request->nombre_usuario,
            "apellido_usuario" => $request->apellido_usuario,
            "correo" => $request->correo,
            "contraseña" => $request->contraseña,

            //Datos que nosotros ingresaremos desde Laravel
            "estado_usuario" => 1,
        );


        //Crear producto y añadir la información del arreglo datos
        $nuevoadministrador = new usuarioModels($datos);
        $nuevoadministrador ->save();


        if ($nuevoadministrador->estado_usuario == 1) {
            $nuevoadministrador->estado_usuario = "Activo";
        }
        else {
            $nuevoadministrador->estado_usuario = "Inactivo";
        }

        return response()->json($nuevoadministrador);
    }

//------------------------------------------------
    public function obtener(Request $request, $id)
    {
        $usurio = Usuaruio::where("usuario.id", "=", $id)
        ->select
        ("usuario.visitas",
        "usuario.sesiones")
        

        ->join
        ("registro", 
        "usuario.registro_estado", "=", "registro.estado");
        
        //Solo obtenemos 1 registro
        $usurio = $usurio->first();

        //Validar si el producto existe
        if ($usurio == null) {
            $mensaje = array(
                "error" => "usuario no encontrado"
            );

            //Respuesta para producto no encontrado - 404
            return response()->json($mensaje, 404);
        }

        return response()->json($usurio);
    }
    //Sustituimos el "Request" por nuestra request personalizada
//---------------------------------------------
    public function eliminar(Request $request, $id) 
    {
        $usurio = UsuarioModels::where("id_usuario", $id)->first();

        if($institucion == null){
            $mensaje = array(
                "error"=> "Usuario  no encontrado."
            );

            return response()->json($mensaje, 404);
        }

        $usurio->estado_usuario = 0;
        $usurio->save();
        $borrado = array(
            "Exito"=> "El usuario fue eliminado exitosamente"
        );

        return response()->json($borrado);
    }
//----------------------------------------------------
    public function actualizar(Request $request, $id)
    {
        $registro=RegistroModels::where("id_registro", $id)->first();
        $registro->nombre_registro = $request->nombre_registro;
        $registro->save();

        return response()->json($request);
    }
}
