<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User; 
use DateTime;
use Auth;
use Carbon\Carbon; 

//Preguntar cómo hacer este controlador adaptando ambas tablas y si se deben incluir todos los campos
class AutenticacionController extends Controller
{
    public function registro(Request $request) 
    {
        $data = array( 
            'contra' => bcrypt($request->contra),
            //Preguntar si es necesario agregar estos datos o cómo deberíamos hacer
            'visita' => 1,
            'sesiones' => 1, 
            'id_progreso' => 1,
            'id_rol' => 1,
        );

        $nuevoUsuario = new User($data);

        $nuevoUsuario->save();

        $mensaje = array( 
            'mensaje' => "Usuario registrado correctamente"
        );

        return response()->json($mensaje);
    }
//-------------------------------------------------------------------------------------------- 
    public function iniciarSesion(Request $request) 
    {
        $credenciales = request(['correo', 'contra']);


        if (Auth::attempt($credenciales) == false)
        {
        $mensaje = array(
            'mensaje' => "Verifique sus credenciales"
        );

        return response()->json($mensaje, 401);
        }

        $usuario = $request->user();

        $generarToken = $usuario->createToken('Admin Access Token');
    

        $token = $generarToken->token;
        $token->save(); 
    
        $respuesta = array(
            'token_acceso' => $generarToken->accessToken,
            'tipo_token' => 'Bearer',
            'fecha_expiracion' => $generarToken->token->expires_at,
        );

        return response()->json($respuesta);
    }
//--------------------------------------------------------------------------------------------
    public function perfil(Request $request)
    {
        $informacion = $request->user(); 

        return response()->json($informacion);
    }
//--------------------------------------------------------------------------------------------
    public function cerrarSesion(Request $request)
    {
        $informacion = $request->user();  

        $informacion->token()->revoke(); 

        $mensaje = array(
            'mensaje' => "Cierre de sesión exitoso"
        );

        return response()->json($mensaje);
    }
}
