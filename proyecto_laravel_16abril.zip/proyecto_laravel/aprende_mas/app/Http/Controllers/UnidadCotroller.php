<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Unidad; 
use App\Models\Materia; 
use App\Models\cuestionario; 


class UnidadCotroller extends Controller
{
    public function listar(Request $request)
    {
        $unidad = Unidad::all();

        $unidad = DB::table('unidad') //Conexión con otras tablas
        ->join('materia', 'unidad.id_materia', '=', 'materia.id_materia') 
        //->join('departamento', 'municipio.id_departamento', '=', 'departamento.id_departamento') //relación departamento con tabla municipio
        ->select("unidad.id_unidad","unidad.nombre_unidad","unidad.estado","materia.id_materia") 
        ->get();


        for ($i=0; $i < count($unidad); $i++) 
        { 
            if ($unidad[$i]->estado_unidad == 1) {
                $unidad[$i]->estado_unidad= "activo";
            }
            else {
                $unidad[$i]->estado_unidad = "inactivo";
            }
        }


        return response()->json($unidad); 
    }
    //------------------------------------------

    public function eliminar(Request $request, $id) 
    {
        $unidad = UnidadModels::where("id_unidad", $id)->first();

        if($unidad == null){
            $mensaje = array(
                "error"=> "unidad no encontrada."
            );

            return response()->json($mensaje, 404);
        }

        $unidad->estado_unidad = 0;
        $unidad->save();
        $borrado = array(
            "Exito"=> "La unidad fue borrada exitosamente"
        );

        return response()->json($borrado);
    }
}
