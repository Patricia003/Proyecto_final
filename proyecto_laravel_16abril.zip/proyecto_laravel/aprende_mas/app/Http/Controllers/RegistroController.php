<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: usuario, registro, grado, municipio, departamento, rol, registro_institucion, institucion
use DateTime;
use App\Models\UsuarioModels; 
use App\Models\RegistroModels;
use App\Models\RegistroInstitucion;
use App\Models\InstitucionModels;
use App\Models\GradoModels; 
use App\Models\MunicipioModels; 
use App\Models\Departamento;
use App\Models\RolModels;

use App\Http\Requests\NuevoAlumnoRequest;

class RegistroController extends Controller
{
//--------------------------------------------------------------------------------------------
    public function listar(Request $request) //Administración de alumno - Preguntar como agrupar el campo apellido y nombre en uno solo porque en la vista sale así
    {
        $registro = RegistroModels::where("registro.id_rol", "=", 2);
        
        $registro = DB::table('registro') 
        ->join("registro_institucion", 'registro.id_registro', '=', 'registro_institucion.id_registro') 
        ->join('institucion', 'registro_institucion.id_institucion', '=', 'institucion.id_institucion') 
        ->join('grado', 'registro.id_grado', '=', 'grado.id_grado') 
        ->select("registro.foto","registro.nombre_registro","registro.apellido_registro", "registro.nie", "registro.correo","institucion.nombre_inst","grado.nivel_academico", "registro.estado_registro")
        ->get();

        for ($i=0; $i < count($registro); $i++) 
        { 
            if ($registro[$i]->estado_registro == 1) {
                $registro[$i]->estado_registro= "activo";
            }
            else {
                $registro[$i]->estado_registro = "inactivo";
            }
        }

        return response()->json($registro); 
    }
//--------------------------------------------------------------------------------------------
    public function obtener(Request $request, $id)
    {
        $registro = DB::table('registro') 
        
        ->where("registro.id_registro", "=", $id)
        ->join("registro_institucion", 'registro.id_registro', '=', 'registro_institucion.id_registro') 
        ->join('institucion', 'registro_institucion.id_institucion', '=', 'institucion.id_institucion') 
        ->join('grado', 'registro.id_grado', '=', 'grado.id_grado') 
        ->select("registro.foto","registro.nombre_registro","registro.apellido_registro", "registro.nie", "registro.correo","institucion.nombre_inst","grado.nivel_academico", "registro.estado_registro")
        ->first();


        if ($registro == null) {
            $mensaje = array("error" => "El registro no fue encontrado"); 

            return response()->json($mensaje, 404);
        }


        if ($registro->estado_registro == 1) {
            $registro->estado_registro= "activo";
        }
        else {
            $registro->estado_registro = "inactivo";
        }
        

        return response()->json($registro);
    }
//--------------------------------------------------------------------------------------------
    public function insertar(NuevoAlumnoRequest $request) //Comparar vista porque acá solo está id_municipio y en vista está el departamento también
    {
        $request->validated();

        $datos = array(
            "nombre_registro" => $request->nombre_registro,
            "apellido_registro" => $request->apellido_registro,
            "nie" => $request->nie,
            "id_grado" => $request->id_grado,
            /*id_institucion no sale en postman porque no está en la tabla registro, tiene su propia
            tabla pivote, preguntar cómo hacer para que salga*/
            "id_institucion" => $request->id_institucion,
            "fecha_nacimiento" => $request->fecha_nacimiento,
            "genero" => $request->genero,
            "id_municipio" => $request->id_municipio,

            "fecha_registro" => (new DateTime())->format("Y-m-d"),
            "estado_registro" => 1
        );


        $nuevoAlumno = new RegistroModels($datos);
        $nuevoAlumno->save();


        switch ($nuevoAlumno->id_grado) { //sustituir número 1 al 5 por el grao que representa
            case 1:
                $nuevoAlumno->id_grado = "Séptimo";
                break;
            case 2:
                $nuevoAlumno->id_grado = "Octavo";
                break;
            case 3:
                $nuevoAlumno->id_grado = "Noveno";
                break;
            case 4:
                $nuevoAlumno->id_grado = "Primer Año Bachillerato";
                break;
            case 5:
                $nuevoAlumno->id_grado = "Segundo Año Bachillerato";
                break;
        }


        switch ($nuevoAlumno->id_municipio) { //sustituir número 1 al 7 por el municipio que representa
            case 1:
                $nuevoAlumno->id_municipio = "Chalatenango";
                break;
            case 2:
                $nuevoAlumno->id_municipio = "Zacatecoluca";
                break;
            case 3:
                $nuevoAlumno->id_municipio = "San Vicente";
                break;
            case 4:
                $nuevoAlumno->id_municipio = "Cuscatlán";
                break;
            case 5:
                $nuevoAlumno->id_municipio = "San Salvador";
                break;
            case 6:
                $nuevoAlumno->id_municipio = "Santa Tecla";
                break;
            case 7:
                $nuevoAlumno->id_municipio = "Sensuntepeque";
                break;
        }


        if ($nuevoAlumno->estado_registro == 1) {
            $nuevoAlumno->estado_registro = "Activo";
        }
        else {
            $nuevoAlumno->estado_registro = "Inactivo";
        }

        return response()->json($nuevoAlumno);
    }
//--------------------------------------------------------------------------------------------
    public function actualizar(Request $request, $id)
    {
        $registro=RegistroModels::where("id_registro", $id)->first();
        $registro->nombre_registro = $request->nombre_registro;
        $registro->apellido_registro = $request->apellido_registro;
        $registro->nie = $request->nie;
        $registro->id_grado = $request->id_grado;
        //Revisar institucion porque da error porque no está directamente en la tabla registro
        /*$registro->id_institucion = $request->id_institucion;*/
        $registro->fecha_nacimiento = $request->fecha_nacimiento;
        $registro->genero = $request->genero;
        $registro->id_municipio = $request->id_municipio;
        $registro->save();

        return response()->json($registro);
    }
//--------------------------------------------------------------------------------------------   
    public function eliminar(Request $request, $id)
    {
        $registro = RegistroModels::where("id_registro", $id)->first();

        if($registro == null){
            $mensaje = array(
                "error"=> "El alumno fue no encontrado."
            );

            return response()->json($mensaje, 404);
        }

        $registro->estado_registro = 0;
        $registro->save();
        $borrado = array(
            "Exito"=> "El registro fue borrado exitosamente"
        );

        return response()->json($borrado);
    }
}
