<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: materia, grado, unidad,
use DateTime;
use App\Models\MateriaModels; 
use App\Models\GradoModels;
use App\Models\Unidad;
use App\Http\Requests\NuevaMateriaRequest;


class MateriaController extends Controller
{
    public function listar(Request $request)
    {
        $materia = MateriaModels::whereNotNull("materia.estado_materia");

        $materia = DB::table('materia') //Conexión con otras tablas
        ->join('unidad', 'unidad.id_materia', '=', 'materia.id_materia')
        ->select("materia.id_materia", "materia.nombre_materia", "unidad.nombre_unidad", "materia.estado_materia")
        ->orderby("materia.id_materia", "asc")
        ->get();


        for ($i=0; $i < count($materia); $i++) //Sustituir 1 y 0 por "activo" e "inactivo"
        { 
            if ($materia[$i]->estado_materia == 1) {
                $materia[$i]->estado_materia= "activo";
            }
            else {
                $materia[$i]->estado_materia = "inactivo";
            }
        }


        return response()->json($materia); //Mostrar datos
    }
    //--------------------------------------------------------------------------------------------
    public function obtener(Request $request, $id) //Solo funciona con materias que tengan unidades
    {
        $materia = DB::table('materia') 
        
        ->where("materia.id_materia", "=", $id)
        ->join('unidad', 'unidad.id_materia', '=', 'materia.id_materia')
        ->select("materia.id_materia", "materia.nombre_materia", "unidad.nombre_unidad", "materia.estado_materia")
        ->first();

        if ($materia == null) {
            $mensaje = array("error" => "La materia no fue encontrada"); 

            return response()->json($mensaje, 404);
        }

        if ($materia->estado_materia == 1) {
            $materia->estado_materia= "activo";
        }
        else {
            $materia->estado_materia = "inactivo";
        }
        

        return response()->json($materia);
    }
    //--------------------------------------------------------------------------------------------
    public function insertar(NuevaMateriaRequest $request) //Falta agregar el campo nivel. Preguntar sobre eso
    {
        $request->validated();

        
        $datos = array(
            "nombre_materia" => $request->nombre_materia,
            "estado_materia" => $request->estado_materia,
        );


        $nuevaMateria = new MateriaModels($datos);
        $nuevaMateria->save();


        if ($nuevaMateria->estado_materia == 1) {
            $nuevaMateria->estado_materia = "Activo";
        }
        else {
            $nuevaMateria->estado_materia = "Inactivo";
        }

        return response()->json($nuevaMateria);
    }
    //--------------------------------------------------------------------------------------------
    public function actualizar(Request $request, $id)
    {
        $materia=MateriaModels::where("id_materia", $id)->first();
        $materia->nombre_materia = $request->nombre_materia;
        $materia->save();

        return response()->json($materia);
    }
    //--------------------------------------------------------------------------------------------
    public function eliminar(Request $request, $id)
    {
        $materia = MateriaModels::where("id_materia", $id)->first();

        if($materia == null){
            $mensaje = array(
                "error"=> "materia no encontrada."
            );

            return response()->json($mensaje, 404);
        }

        $materia->estado_materia = 0;
        $materia->save();
        $borrado = array(
            "Exito"=> "La materia fue borrada exitosamente"
        );

        return response()->json($borrado);
    }
}
