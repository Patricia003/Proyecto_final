<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use DateTime;

//Tablas involucradas: tema, cuestionario
use App\Models\TemaModels;
use App\Models\CuestionarioModels;
use App\Models\MateriaModels;

class TemaController extends Controller
{
    public function listar(Request $request)
    {
        $tema = TemaModels::where("tema.estado_tema", "=", 1) //Condicion
        ->select("tema.titulo"); //Campos a mostrar
        $tema = $tema->get();

        return response()->json($tema); //Mostrar datos
    }
}
