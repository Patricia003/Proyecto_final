<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: cuestionario, registro, pregunta, insignia, grado, tema
use DateTime;
use App\Models\CuestionarioModels; 
use App\Models\RegistroModels;
use App\Models\PreguntaModels; 
use App\Models\InsigniaModels; 
use App\Models\GradoModels; 
use App\Models\TemaModels; 
use App\Http\Requests\NuevoCuestionarioRequest;

class CuestionarioController extends Controller
{
    public function listar(Request $request)
    {
        $cuestionario = cuestionarioModels::all(); //Mostrar todas las preguntas

        $cuestionario = DB::table('cuestionario')
        ->join('tema', 'cuestionario.id_tema', '=', 'tema.id_tema') //relación tema con tabla cuestionario
        /*->join('pregunta', 'pregunta.id_cuestionario', '=', 'cuestionario.id_cuestionario') //relación pregunta con tabla cuestionario*/
        ->select("tema.titulo","cuestionario.duracion_cuestionario", "cuestionario.estado_cuestionario") //Campos a mostrar
        ->get();

        for ($i=0; $i < count($cuestionario); $i++) //Sustituir 1 y 0 por "activo" e "inactivo"
        { 
            if ($cuestionario[$i]->estado_cuestionario == 1) {
                $cuestionario[$i]->estado_cuestionario= "activo";
            }
            else {
                $cuestionario[$i]->estado_cuestionario = "inactivo";
            }
        }

        return response()->json($cuestionario); //Mostrar datos

        
    }
    //----------------------------------------------------------

    public function obtener(Request $request, $id)
    {
        $cuestionario = DB::table('cuestionario') 
        ->where("cuestionario.id_cuestionario", "=", $id)
        ->join('tema', 'institucion.titulo', '=', 'tema.titulo') 
        ->select("cuestionario.id_cuestionario","cuestionario.tutulo", "estado_cuaetionario") 
        ->first();

        
        if ($cuestionario == null) {
            $mensaje = array("error" => "El cuestiinario no fue encontrado"); 

            return response()->json($mensaje, 404);
        }

   
        if ($cuestionario->estado_cuestionario == 1) {
            $cuestionario->estado_cuestionario= "activo";
        }
        else {
            $cuestionario->estado_cuestionario = "inactivo";
        }
        

        return response()->json($cuestionario);
    }
   //------------------------------------------------------------
   public function insertar(Request $request)
    {
        $request->validated();

        $datos = array(
       
            "estado" => $request->estado,
            "materia" => $request->matria,
            "unidad" => $request->unidad,
            "titulo" => $request->titulo,

   
            "estado_cuestionario" => 1,
        );



        $nuevoCuestionario = new CuestionarioModels($datos);
        $nuevoCuestionario->save();


        if ($nuevoCuestionario->estado_cuestionario == 1) {
            $nuevoCuestionario->estado_cuestionario = "Activo";
        }
        else {
            $nuevoCuestionario->estado_cuestionario = "Inactivo";
        }

        return response()->json($nuevoCuestionario);
    }
//----------------------------------------------------------------
    public function actualizar(Request $request, $id)
    {
        $cuestionario=CuestionarioModels::where("titulo", $id)->first();
        $cuestionario->titulo_cuestionario = $request->titulo_cuestionario;
        $cuestionario->save();

        return response()->json($cuestionario);
    }
//----------------------------------------------------------------
    public function eliminar(Request $request, $id) 
    {
        $cuestionario = CuestionarioModels::where("id_cuestionario", $id)->first();

        if($cuestionario == null){
            $mensaje = array(
                "error"=> "Cuestionario no encontrado."
            );

            return response()->json($mensaje, 404);
        }

        $cuestionario->estado_cuestionario = 0;
        $cuestionario->save();
        $borrado = array(
            "Exito"=> "El cuetionario fue borrado exitosamente"
        );

        return response()->json($borrado);
    }

}
