<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


use App\Http\Controllers\RegistroController;
use App\Http\Controllers\InstitucionController;
use App\Http\Controllers\MateriaController;
use App\Http\Controllers\EncuestaController;
use App\Http\Controllers\TemaController;
use App\Http\Controllers\CuestionarioController;
use App\Http\Controllers\PreguntaController;
use App\Http\Controllers\InsigniaController;
use App\Http\Controllers\GradoController;
use App\Http\Controllers\UnidadController;
use App\Http\Controllers\UsuarioController;

use App\Http\Controllers\AutenticacionController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//Rutas de controlador Autenticación
Route::post("/auth/registro", [AutenticacionController::class, "registro"]);
Route::post("/auth/iniciar-sesion", [AutenticacionController::class, "iniciarSesion"]);

#Rutas protegidas
Route::middleware(['auth:api'])->group(function () {
    Route::get("/auth/perfil", [AutenticacionController::class, "perfil"]); 
    Route::get("/auth/cerrar-sesion", [AutenticacionController::class, "cerrarSesion"]); 
});


//Rutas de controlador institución
Route::get("/institucion-listar", [InstitucionController::class, "listar"]);
Route::get("/institucion-obtener/{id}", [InstitucionController::class, "obtener"]);
Route::post("/institucion-insertar", [InstitucionController::class, "insertar"]);
Route::post("/institucion-actualizar/{id}", [InstitucionController::class, "actualizar"]);
Route::post("/institucion-eliminar/{id}", [InstitucionController::class, "eliminar"]);


//Rutas de controlador Registro (alumnos)
Route::get("/registro-listar", [RegistroController::class, "listar"]);
Route::get("/registro-obtener/{id}", [RegistroController::class, "obtener"]);
Route::post("/registro-insertar", [RegistroController::class, "insertar"]);
Route::post("/registro-actualizar/{id}", [RegistroController::class, "actualizar"]);
Route::post("/registro-eliminar/{id}", [RegistroController::class, "eliminar"]);


//Rutas de controlador Grado
Route::get("/grado-listar", [GradoController::class, "listar"]);
Route::get("/grado-obtener/{id}", [GradoController::class, "obtener"]);
Route::post("/grado-insertar", [GradoController::class, "insertar"]);
Route::post("/grado-actualizar/{id}", [GradoController::class, "actualizar"]);
Route::post("/grado-eliminar/{id}", [GradoController::class, "eliminar"]);


//Rutas de controlador Materia
Route::get("/materia-listar", [MateriaController::class, "listar"]);
Route::get("/materia-obtener/{id}", [MateriaController::class, "obtener"]);
Route::post("/materia-insertar", [MateriaController::class, "insertar"]);
Route::post("/materia-actualizar/{id}", [MateriaController::class, "actualizar"]);
Route::post("/materia-eliminar/{id}", [MateriaController::class, "eliminar"]);





//Rutas de controlador unidades
Route::get("/listar-unidad", [UnidadCotroller::class, "listar"]);
Route::get("/unidad-obtener/{id}", [UnidadCotroller::class, "obtener"]);
Route::post("/unidad-insertar", [UnidadCotroller::class, "insertar"]);
Route::post("/unidad-actualizar/{id}", [UnidadCotroller::class, "actualizar"]);
Route::post("/unidad-eliminar/{id}", [UnidadCotroller::class, "eliminar"]);


//Rutas de controlador cuestionario
Route::get("/cuestionario-listar", [CuestionarioController::class, "listar"]);
Route::get("/cuestionario-obtener/{id}", [CuestionarioController::class, "obtener"]);
Route::post("/cuestionario-insertar", [CuestionarioController::class, "insertar"]);
Route::post("/cuestionario-actualizar/{id}", [CuestionarioController::class, "actualizar"]);
Route::post("/cuestionario-eliminar/{id}", [CuestionarioController::class, "eliminar"]);


//Rutas de controlador encuesta
Route::get("/encuesta-listar", [EncuestaController::class, "listar"]);
Route::get("/encuesta-obtener/{id}", [EncuestaController::class, "obtener"]);
Route::post("/encuesta-insertar", [EncuestaController::class, "insertar"]);
Route::post("/encuesta-actualizar/{id}", [EncuestaController::class, "actualizar"]);
Route::post("/encuesta-eliminar/{id}", [EncuestaController::class, "eliminar"]);


//Rutas de controlador administradores
Route::get("/usuario-listar", [UsuarioController::class, "listar"]);
Route::post("/actualizar-registro/{id}", [UsuarioController::class, "actualizar"]);
Route::post("/usuario-eliminar/{id}", [UsuarioController::class, "eliminar"]);
Route::get("/usuario-obtener/{id}", [UsuarioController::class, "obtener"]);








