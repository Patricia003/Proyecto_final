<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


use App\Http\Controllers\RegistroController;
use App\Http\Controllers\InstitucionController;
use App\Http\Controllers\MateriaController;
use App\Http\Controllers\EncuestaController;
use App\Http\Controllers\TemaController;
use App\Http\Controllers\CuestionarioController;
use App\Http\Controllers\PreguntaController;
use App\Http\Controllers\InsigniaController;
use App\Http\Controllers\GradoController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//Rutas de controlador institución
Route::get("/institucion-listar", [InstitucionController::class, "listar"]);
Route::get("/institucion-obtener/{id}", [InstitucionController::class, "obtener"]);
Route::post("/institucion-insertar", [InstitucionController::class, "insertar"]);
Route::post("/institucion-actualizar/{id}", [InstitucionController::class, "actualizar"]);
Route::post("/institucion-eliminar/{id}", [InstitucionController::class, "eliminar"]);

//Rutas de controlador Registro
Route::get("/registro-listar1", [RegistroController::class, "listar1"]);
Route::get("/registro-listar2", [RegistroController::class, "listar2"]);
Route::get("/registro-listar3", [RegistroController::class, "listar3"]);
Route::get("/registro-obtener/{id}", [RegistroController::class, "obtener"]);
Route::post("/registro-insertar", [RegistroController::class, "insertar"]);
Route::post("/registro-actualizar/{id}", [RegistroController::class, "actualizar"]);
Route::post("/registro-eliminar/{id}", [RegistroController::class, "eliminar"]);

//Rutas de controlador Grado
Route::get("/grado-listar", [GradoController::class, "listar"]);
Route::get("/grado-obtener/{id}", [GradoController::class, "obtener"]);
Route::post("/grado-insertar", [GradoController::class, "insertar"]);
Route::post("/grado-actualizar/{id}", [GradoController::class, "actualizar"]);
Route::post("/grado-eliminar/{id}", [GradoController::class, "eliminar"]);

//Rutas de controlador Materia
Route::get("/materia-listar", [MateriaController::class, "listar"]);
Route::get("/materia-obtener/{id}", [MateriaController::class, "obtener"]);
Route::post("/materia-insertar", [MateriaController::class, "insertar"]);
Route::post("/materia-actualizar/{id}", [MateriaController::class, "actualizar"]);
Route::post("/materia-eliminar/{id}", [MateriaController::class, "eliminar"]);





Route::get("/encuesta-listar", [EncuestaController::class, "listar"]);
Route::get("/tema-listar", [TemaController::class, "listar"]);
Route::get("/cuestionario-listar", [CuestionarioController::class, "listar"]);
Route::get("/pregunta-listar", [PreguntaController::class, "listar"]);
Route::get("/insignia-listar", [InsigniaController::class, "listar"]);


