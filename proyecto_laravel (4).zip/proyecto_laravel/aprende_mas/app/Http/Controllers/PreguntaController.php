<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: pregunta, cuestionario
use DateTime;
use App\Models\PreguntaModels;
use App\Models\CuestionarioModels;

class PreguntaController extends Controller
{
    public function listar(Request $request) //Administración de usuario
    {
        $pregunta = PreguntaModels::where("pregunta.estado_pregunta", "=", 1) //Condición
        ->select("pregunta.puntaje_obtenido", "pregunta.estado_pregunta") //Campos a mostrar
        ->join("cuestionario", "pregunta.id_cuestionario", "=", "cuestionario.id_cuestionario"); //relación usuario con pregunta
        $pregunta = $pregunta->get();

        
        for ($i=0; $i < count($pregunta); $i++) //Sustituir 1 y 0 por "activa" e "inactivo"
        { 
            if ($pregunta[$i]->estado_pregunta == 1) {
                $pregunta[$i]->estado_pregunta= "activo";
            }
            else {
                $pregunta[$i]->estado_pregunta = "inactivo";
            }
        }

        return response()->json($pregunta); //mostrar datos en pantalla
    }
}
