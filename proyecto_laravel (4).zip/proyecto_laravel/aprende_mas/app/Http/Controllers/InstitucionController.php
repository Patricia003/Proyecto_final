<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: institucion, municipio, departamento
use DateTime;
use App\Models\InstitucionModels;
use App\Models\MunicipioModels;
use App\Models\Departamento; 


class InstitucionController extends Controller
{
    public function listar(Request $request)
    {
        $institucion = InstitucionModels::all();

        $institucion = DB::table('institucion') //Conexión con otras tablas
        ->join('municipio', 'institucion.id_municipio', '=', 'municipio.id_municipio') //relación municipio con tabla institucion
        ->join('departamento', 'municipio.id_departamento', '=', 'departamento.id_departamento') //relación departamento con tabla municipio
        ->select("institucion.id_institucion","institucion.nombre_inst","institucion.tipo_institucion", "municipio.nombre_municipio","departamento.nombre_departamento", "estado_institucion") //Campos a mostrar
        ->get();


        for ($i=0; $i < count($institucion); $i++) //Sustituir 1 y 0 por "activo" e "inactivo"
        { 
            if ($institucion[$i]->estado_institucion == 1) {
                $institucion[$i]->estado_institucion= "activo";
            }
            else {
                $institucion[$i]->estado_institucion = "inactivo";
            }
        }


        return response()->json($institucion); //Mostrar datos en pantalla
    }
    //--------------------------------------------------------------------------------------------
    public function obtener(Request $request, $id)
    {
        $institucion = InstitucionModels::where("institucion.id", "=", $id);


        $institucion = DB::table('institucion') //Conexión con otras tablas
        ->join('municipio', 'institucion.id_municipio', '=', 'municipio.id_municipio') //relación municipio con tabla institucion
        ->join('departamento', 'municipio.id_departamento', '=', 'departamento.id_departamento') //relación departamento con tabla municipio
        ->select("institucion.id_institucion","institucion.nombre_inst","institucion.tipo_institucion", "municipio.nombre_municipio","departamento.nombre_departamento", "estado_institucion") //Campos a mostrar //seleccionar los datos que queremos mostrar
        ->first();


        for ($i=0; $i < count($institucion); $i++) //Sustituir 1 y 0 por "activo" e "inactivo"
        { 
            if ($institucion[$i]->estado_institucion == 1) {
                $institucion[$i]->estado_institucion= "activo";
            }
            else {
                $institucion[$i]->estado_institucion = "inactivo";
            }
        }

        
        //Si el registro no existe, se mostrará un mensaje de error
        if ($institucion == null) {
            $mensaje = array("error" => "La institucion no fue encontrada"); //Mensaje de error

            return response()->json($mensaje, 404);
        }


        return response()->json($institucion);
    }
//--------------------------------------------------------------------------------------------
    public function insertar(Request $request)
    {
        $datos = array( //Datos que vamos a insertar
            "nombre" => $request->nombre,
            "descripcion" => $request->descripcion,
            "estado" => 1,
            "fecha_registro" => (new DateTime())->format("Y-m-d H-i-s"),
            "fecha_actualizacion" => (new DateTime())->format("Y-m-d H-i-s"),
        );

        $nuevaCategoria = new Categoria($datos);
        $nuevaCategoria->save();

        return response()->json($nuevaCategoria);
    }
//--------------------------------------------------------------------------------------------
    public function actualizar(Request $request, $id)
    {
        $cambios=0; //Variable para realizar condición del final

        /*Se solicitarán los datos de nombre, descripcion y fecha de actualización para hacer 
        la consulta*/
        $categoria=Categoria::where("id", $id)->first();

        //Condicional para permitir que el campo "nombre" vaya nulo y no dé un error
        if ($request->nombre != null){
            $categoria->nombre = $request->nombre;
            $cambios++;
        }

        //Condicional para permitir que el campo "descripcion" vaya nulo y no dé un error
        if ($request->descripcion != null){
            $categoria->descripcion = $request->descripcion;
            $cambios++;
        }

        if ($cambios > 0) { //Condicional para que la fecha solamente se actualice si se cambia el nombre o la descripción
            $categoria->fecha_actualizacion = (new DateTime())->format("Y-m-d H:i:s");
        }

        $categoria->save(); //Guarda los datos

        return response()->json($categoria); //Devuelve los datos de la variable $categoria
    }
//--------------------------------------------------------------------------------------------
    public function eliminar(Request $request, $id) 
    {
        $categoria=Categoria::where("id", $id)->first();

        //Validamos que el registro exista
        if($categoria == null){
            $mensaje = array(
                "error"=> "Categoria no encontrada."
            );

            //Respuesta para categoria no encontrada - 404
            return response()->json($mensaje, 404);
        }

        //Síntaxis de un comando update. Solamente se cambiará el estado
        $categoria->estado = 0;
        $categoria->save();

        /*No usar esta línea, es solamente en caso de emergencia. Esto elliminará un dato
        permanentemente*/
        #categoria->delete();
        
        //Arreglo para mostrar como mensaje luego de que la categoria haya sido borrada
        $borrado = array(
            "Exito"=> "La categoria fue borrada exitosamente"
        );

        return response()->json($borrado);
    }
}

