<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: usuario, registro, grado, municipio, departamento, rol, registro_institucion, institucion
use DateTime;
use App\Models\UsuarioModels; 
use App\Models\RegistroModels;
use App\Models\RegistroInstitucion;
use App\Models\InstitucionModels;
use App\Models\GradoModels; 
use App\Models\MunicipioModels; 
use App\Models\Departamento;
use App\Models\RolModels;

class RegistroController extends Controller
{
    public function listar1(Request $request) //Administración de usuario
    {
        $registro = RegistroModels::where("registro.id_rol", "=", 1) //Condición
        ->select("registro.nombre_registro","registro.apellido_registro", "registro.correo","usuario.visita","usuario.sesiones","registro.estado_registro") //Campos a mostrar
        ->join("usuario", "registro.id_usuario", "=", "usuario.id_usuario"); //relación usuario con registro
        $registro = $registro->get();

        
        for ($i=0; $i < count($registro); $i++) //Sustituir 1 y 0 por "activa" e "inactivo"
        { 
            if ($registro[$i]->estado_registro == 1) {
                $registro[$i]->estado_registro= "activo";
            }
            else {
                $registro[$i]->estado_registro = "inactivo";
            }
        }

        return response()->json($registro); //mostrar datos en pantalla
    }


    public function listar2(Request $request) //Perfil de usuario
    {
        $registro = RegistroModels::where("registro.id_rol", "=", 1); //Condición
        
        $registro = DB::table('registro') //Conexión con otras tablas
        ->join("registro_institucion", 'registro.id_registro', '=', 'registro_institucion.id_registro') //relación registro con pivote registro_institucion
        ->join('institucion', 'registro_institucion.id_institucion', '=', 'institucion.id_institucion') //relación institucion con pivote registro_institucion
        ->join('municipio', 'registro.id_municipio', '=', 'municipio.id_municipio') //relación municipio con tabla registro
        ->join('departamento', 'municipio.id_departamento', '=', 'departamento.id_departamento') //relación departamento con tabla municipio
        ->select("registro.nombre_registro","registro.apellido_registro", "registro.correo","municipio.nombre_municipio","departamento.nombre_departamento","registro.foto") //Campos a mostrar
        ->get();

        return response()->json($registro); //mostrar datos en pantalla
    }


    public function listar3(Request $request) //Administración de alumno
    {
        $registro = RegistroModels::where("registro.id_rol", "=", 2); //Condición
        
        $registro = DB::table('registro') //Conexión con otras tablas
        ->join("registro_institucion", 'registro.id_registro', '=', 'registro_institucion.id_registro') //relación registro con pivote registro_institucion
        ->join('institucion', 'registro_institucion.id_institucion', '=', 'institucion.id_institucion') //relación institucion con pivote registro_institucion
        ->join('grado', 'registro.id_grado', '=', 'grado.id_grado') //relación grado con registro
        ->select("registro.foto","registro.nombre_registro","registro.apellido_registro", "registro.nie", "registro.correo","institucion.nombre_inst","grado.nivel_academico", "registro.estado_registro") //Campos a mostrar
        ->get();

        for ($i=0; $i < count($registro); $i++) //Sustituir 1 y 0 por "activa" e "inactivo"
        { 
            if ($registro[$i]->estado_registro == 1) {
                $registro[$i]->estado_registro= "activo";
            }
            else {
                $registro[$i]->estado_registro = "inactivo";
            }
        }

        return response()->json($registro); //mostrar datos en pantalla
    }
    public function obtener(Request $request, $id)
    {
        $producto = Producto::where("productos.id", "=", $id)
        ->select
        ("productos.id", 
        "productos.producto", 
        "productos.descripcion", 
        "productos.precio_unitario",
        "categorias.nombre AS categoria", 
        "productos.fecha_registro")

        ->join
        ("categorias", 
        "productos.categoria_id", "=", "categorias.id");
        
        //Solo obtenemos 1 registro
        $producto = $producto->first();

        //Validar si el producto existe
        if ($producto == null) {
            $mensaje = array(
                "error" => "Producto no encontrado"
            );

            //Respuesta para producto no encontrado - 404
            return response()->json($mensaje, 404);
        }

        return response()->json($producto);
    }
    //Sustituimos el "Request" por nuestra request personalizada
    public function insertar(NuevoProductoRequest $request)
    {
        //Activamos las validaciones del request que creamos
        $request->validated();

        //Determinar si el dato que escribamos en el campo categoria_id existe
        $categoria = Categoria::where("id", "=", $request->categoria_id)->first();

        //Condición para evaluar si hay una categoria o no
        if ($categoria == null) {
            $mensaje = array(
                "error" => "Categoria no encontrada"
            );

            //Respuesta para categoria no encontrada - 404
            return response()->json($mensaje, 404);
        }

        $datos = array(
            //Datos que debemos ingresar desde PostMan
            "producto" => $request->producto,
            "descripcion" => $request->descripcion,
            "precio_unitario" => $request->precio_unitario,
            "categoria_id"=> $request->categoria_id,

            //Datos que nosotros ingresaremos desde Laravel
            "estado" => 1,
            "fecha_registro" => (new DateTime())->format("Y-m-d H-i-s"),
            "fecha_actualizacion" => (new DateTime())->format("Y-m-d H-i-s"),
        );

        //Crear producto y añadir la información del arreglo datos
        $nuevoProducto = new Producto($datos);
        $nuevoProducto->save();

        return response()->json($nuevoProducto);
    }
    public function actualizar(Request $request, $id)
    {
        $producto=Producto::where("id", $id)->first();
        $producto->producto = $request->producto;
        $producto->descripcion = $request->descripcion;
        $producto->precio_unitario = $request->precio_unitario;
        $producto->categoria_id = $request->categoria_id;
        $producto->fecha_actualizacion = (new DateTime())->format("Y-m-d H:i:s");

        $producto->save();

        return response()->json($producto);
    }
    public function eliminar(Request $request, $id)
    {
        $producto = Producto::where("id", $id)->first();

        if($producto == null){
            $mensaje = array(
                "error"=> "Producto no encontrado."
            );

            return response()->json($mensaje, 404);
        }

        $producto->estado = 0;
        $producto->save();
        $borrado = array(
            "Exito"=> "El producto fue borrado exitosamente"
        );

        return response()->json($borrado);
    }
}
