<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GradoController extends Controller
{
    public function listar(Request $request)
    {
        //SELECT id, producto, descripcion, precio_unitario FROM productos WHERE estado = 1
        $producto = Producto::where("productos.estado", "=", 1)

        /*Es recomendable agregar "productos." al principio de cada campo para especificar
        de qué tabla provienen los datos*/

        /*"categorias.nombre AS categoria - esto modifica el nombre de la columna temporalmente. 
        solamente al mostrar los datos en PostMan*/
        ->select("productos.id", "productos.producto", "productos.descripcion", "categorias.nombre AS categoria",
        "productos.precio_unitario")

        //Join para mostrar los datos de la tabla de categorias
        ->join("categorias", "productos.categoria_id", "=", "categorias.id");
        $producto = $producto->get();

        return response()->json($producto);
    }
    public function obtener(Request $request, $id)
    {
        $producto = Producto::where("productos.id", "=", $id)
        ->select
        ("productos.id", 
        "productos.producto", 
        "productos.descripcion", 
        "productos.precio_unitario",
        "categorias.nombre AS categoria", 
        "productos.fecha_registro")

        ->join
        ("categorias", 
        "productos.categoria_id", "=", "categorias.id");
        
        //Solo obtenemos 1 registro
        $producto = $producto->first();

        //Validar si el producto existe
        if ($producto == null) {
            $mensaje = array(
                "error" => "Producto no encontrado"
            );

            //Respuesta para producto no encontrado - 404
            return response()->json($mensaje, 404);
        }

        return response()->json($producto);
    }
    //Sustituimos el "Request" por nuestra request personalizada
    public function insertar(NuevoProductoRequest $request)
    {
        //Activamos las validaciones del request que creamos
        $request->validated();

        //Determinar si el dato que escribamos en el campo categoria_id existe
        $categoria = Categoria::where("id", "=", $request->categoria_id)->first();

        //Condición para evaluar si hay una categoria o no
        if ($categoria == null) {
            $mensaje = array(
                "error" => "Categoria no encontrada"
            );

            //Respuesta para categoria no encontrada - 404
            return response()->json($mensaje, 404);
        }

        $datos = array(
            //Datos que debemos ingresar desde PostMan
            "producto" => $request->producto,
            "descripcion" => $request->descripcion,
            "precio_unitario" => $request->precio_unitario,
            "categoria_id"=> $request->categoria_id,

            //Datos que nosotros ingresaremos desde Laravel
            "estado" => 1,
            "fecha_registro" => (new DateTime())->format("Y-m-d H-i-s"),
            "fecha_actualizacion" => (new DateTime())->format("Y-m-d H-i-s"),
        );

        //Crear producto y añadir la información del arreglo datos
        $nuevoProducto = new Producto($datos);
        $nuevoProducto->save();

        return response()->json($nuevoProducto);
    }
    public function actualizar(Request $request, $id)
    {
        $producto=Producto::where("id", $id)->first();
        $producto->producto = $request->producto;
        $producto->descripcion = $request->descripcion;
        $producto->precio_unitario = $request->precio_unitario;
        $producto->categoria_id = $request->categoria_id;
        $producto->fecha_actualizacion = (new DateTime())->format("Y-m-d H:i:s");

        $producto->save();

        return response()->json($producto);
    }
    public function eliminar(Request $request, $id)
    {
        $producto = Producto::where("id", $id)->first();

        if($producto == null){
            $mensaje = array(
                "error"=> "Producto no encontrado."
            );

            return response()->json($mensaje, 404);
        }

        $producto->estado = 0;
        $producto->save();
        $borrado = array(
            "Exito"=> "El producto fue borrado exitosamente"
        );

        return response()->json($borrado);
    }
}
