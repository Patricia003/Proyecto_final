<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: materia, tema
use DateTime;
use App\Models\MateriaModels; 
use App\Models\TemaModels;


class MateriaController extends Controller
{
    public function listar(Request $request)
    {
        $materia = MateriaModels::where("materia.estado_materia", "=", 1) //Condicion
        ->select("materia.nombre_materia","materia.estado_materia"); //Campos a mostrar
        $materia = $materia->get();


        for ($i=0; $i < count($materia); $i++) //Sustituir 1 y 0 por "activo" e "inactivo"
        { 
            if ($materia[$i]->estado_materia == 1) {
                $materia[$i]->estado_materia= "activo";
            }
            else {
                $materia[$i]->estado_materia = "inactivo";
            }
        }


        return response()->json($materia); //Mostrar datos
    }
    public function obtener(Request $request, $id)
    {
        $producto = Producto::where("productos.id", "=", $id)
        ->select
        ("productos.id", 
        "productos.producto", 
        "productos.descripcion", 
        "productos.precio_unitario",
        "categorias.nombre AS categoria", 
        "productos.fecha_registro")

        ->join
        ("categorias", 
        "productos.categoria_id", "=", "categorias.id");
        
        //Solo obtenemos 1 registro
        $producto = $producto->first();

        //Validar si el producto existe
        if ($producto == null) {
            $mensaje = array(
                "error" => "Producto no encontrado"
            );

            //Respuesta para producto no encontrado - 404
            return response()->json($mensaje, 404);
        }

        return response()->json($producto);
    }
    //Sustituimos el "Request" por nuestra request personalizada
    public function insertar(NuevoProductoRequest $request)
    {
        //Activamos las validaciones del request que creamos
        $request->validated();

        //Determinar si el dato que escribamos en el campo categoria_id existe
        $categoria = Categoria::where("id", "=", $request->categoria_id)->first();

        //Condición para evaluar si hay una categoria o no
        if ($categoria == null) {
            $mensaje = array(
                "error" => "Categoria no encontrada"
            );

            //Respuesta para categoria no encontrada - 404
            return response()->json($mensaje, 404);
        }

        $datos = array(
            //Datos que debemos ingresar desde PostMan
            "producto" => $request->producto,
            "descripcion" => $request->descripcion,
            "precio_unitario" => $request->precio_unitario,
            "categoria_id"=> $request->categoria_id,

            //Datos que nosotros ingresaremos desde Laravel
            "estado" => 1,
            "fecha_registro" => (new DateTime())->format("Y-m-d H-i-s"),
            "fecha_actualizacion" => (new DateTime())->format("Y-m-d H-i-s"),
        );

        //Crear producto y añadir la información del arreglo datos
        $nuevoProducto = new Producto($datos);
        $nuevoProducto->save();

        return response()->json($nuevoProducto);
    }
    public function actualizar(Request $request, $id)
    {
        $producto=Producto::where("id", $id)->first();
        $producto->producto = $request->producto;
        $producto->descripcion = $request->descripcion;
        $producto->precio_unitario = $request->precio_unitario;
        $producto->categoria_id = $request->categoria_id;
        $producto->fecha_actualizacion = (new DateTime())->format("Y-m-d H:i:s");

        $producto->save();

        return response()->json($producto);
    }
    public function eliminar(Request $request, $id)
    {
        $producto = Producto::where("id", $id)->first();

        if($producto == null){
            $mensaje = array(
                "error"=> "Producto no encontrado."
            );

            return response()->json($mensaje, 404);
        }

        $producto->estado = 0;
        $producto->save();
        $borrado = array(
            "Exito"=> "El producto fue borrado exitosamente"
        );

        return response()->json($borrado);
    }
}
