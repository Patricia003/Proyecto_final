<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class InstitucionModels extends Model
{
    use HasFactory;

    protected $table = "institucion"; //Tabla creada en la base de datos
    
    public $timestamps = false; // Desactiva las fechas automaticas.

    protected $fillable = [  //campo requerido para un método insert
        "nombre_inst",
        "tipo_institucion",
        "estado_institucion",
        "id_municipio",
    ];
}
