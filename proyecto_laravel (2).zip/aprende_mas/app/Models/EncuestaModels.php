<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EncuestaModels extends Model
{
    use HasFactory;

    protected $table = "encuesta"; //Tabla creada en la base de datos
    
    public $timestamps = false; // Esto desactiva las fechas automaticas. Siempre desactival o da error

    protected $fillable = [  //campo requerido para un método insert
       'preg_encuesta',
       'resp_encuesta',
       'respuesta_user',
       'comentario',
       'puntaje_maximo',
       'puntaje_obtenido',
       'estado_encuesta',
    ];
}
