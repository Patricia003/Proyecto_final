<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: cuestionario, registro, pregunta, insignia, grado, tema
use DateTime;
use App\Models\CuestionarioModels; 
use App\Models\RegistroModels;
use App\Models\PreguntaModels; 
use App\Models\InsigniaModels; 
use App\Models\GradoModels; 
use App\Models\TemaModels; 

class CuestionarioController extends Controller
{
    public function listar(Request $request)
    {
        $cuestionario = cuestionarioModels::all(); //Mostrar todas las preguntas

        $cuestionario = DB::table('cuestionario')
        ->join('tema', 'cuestionario.id_tema', '=', 'tema.id_tema') //relación tema con tabla cuestionario
        /*->join('pregunta', 'pregunta.id_cuestionario', '=', 'cuestionario.id_cuestionario') //relación pregunta con tabla cuestionario*/
        ->select("tema.titulo","cuestionario.duracion_cuestionario", "cuestionario.estado_cuestionario") //Campos a mostrar
        ->get();

        for ($i=0; $i < count($cuestionario); $i++) //Sustituir 1 y 0 por "activo" e "inactivo"
        { 
            if ($cuestionario[$i]->estado_cuestionario == 1) {
                $cuestionario[$i]->estado_cuestionario= "activo";
            }
            else {
                $cuestionario[$i]->estado_cuestionario = "inactivo";
            }
        }

        return response()->json($cuestionario); //Mostrar datos
    }
}
