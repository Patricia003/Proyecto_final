<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: usuario, registro, grado, municipio, departamento, rol, registro_institucion, institucion
use DateTime;
use App\Models\UsuarioModels; 
use App\Models\RegistroModels;
use App\Models\RegistroInstitucion;
use App\Models\InstitucionModels;
use App\Models\GradoModels; 
use App\Models\MunicipioModels; 
use App\Models\Departamento;
use App\Models\RolModels;

class RegistroController extends Controller
{
    public function listar1(Request $request) //Administración de usuario
    {
        $registro = RegistroModels::where("registro.id_rol", "=", 1) //Condición
        ->select("registro.nombre_registro","registro.apellido_registro", "registro.correo","usuario.visita","usuario.sesiones","registro.estado_registro") //Campos a mostrar
        ->join("usuario", "registro.id_usuario", "=", "usuario.id_usuario"); //relación usuario con registro
        $registro = $registro->get();

        
        for ($i=0; $i < count($registro); $i++) //Sustituir 1 y 0 por "activa" e "inactivo"
        { 
            if ($registro[$i]->estado_registro == 1) {
                $registro[$i]->estado_registro= "activo";
            }
            else {
                $registro[$i]->estado_registro = "inactivo";
            }
        }

        return response()->json($registro); //mostrar datos en pantalla
    }


    public function listar2(Request $request) //Perfil de usuario
    {
        $registro = RegistroModels::where("registro.id_rol", "=", 1); //Condición
        
        $registro = DB::table('registro') //Conexión con otras tablas
        ->join("registro_institucion", 'registro.id_registro', '=', 'registro_institucion.id_registro') //relación registro con pivote registro_institucion
        ->join('institucion', 'registro_institucion.id_institucion', '=', 'institucion.id_institucion') //relación institucion con pivote registro_institucion
        ->join('municipio', 'registro.id_municipio', '=', 'municipio.id_municipio') //relación municipio con tabla registro
        ->join('departamento', 'municipio.id_departamento', '=', 'departamento.id_departamento') //relación departamento con tabla municipio
        ->select("registro.nombre_registro","registro.apellido_registro", "registro.correo","municipio.nombre_municipio","departamento.nombre_departamento","registro.foto") //Campos a mostrar
        ->get();

        return response()->json($registro); //mostrar datos en pantalla
    }


    public function listar3(Request $request) //Administración de alumno
    {
        $registro = RegistroModels::where("registro.id_rol", "=", 2); //Condición
        
        $registro = DB::table('registro') //Conexión con otras tablas
        ->join("registro_institucion", 'registro.id_registro', '=', 'registro_institucion.id_registro') //relación registro con pivote registro_institucion
        ->join('institucion', 'registro_institucion.id_institucion', '=', 'institucion.id_institucion') //relación institucion con pivote registro_institucion
        ->join('grado', 'registro.id_grado', '=', 'grado.id_grado') //relación grado con registro
        ->select("registro.foto","registro.nombre_registro","registro.apellido_registro", "registro.nie", "registro.correo","institucion.nombre_inst","grado.nivel_academico", "registro.estado_registro") //Campos a mostrar
        ->get();

        for ($i=0; $i < count($registro); $i++) //Sustituir 1 y 0 por "activa" e "inactivo"
        { 
            if ($registro[$i]->estado_registro == 1) {
                $registro[$i]->estado_registro= "activo";
            }
            else {
                $registro[$i]->estado_registro = "inactivo";
            }
        }

        return response()->json($registro); //mostrar datos en pantalla
    }
}
