<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: materia, tema
use DateTime;
use App\Models\MateriaModels; 
use App\Models\TemaModels;


class MateriaController extends Controller
{
    public function listar(Request $request)
    {
        $materia = MateriaModels::where("materia.estado_materia", "=", 1) //Condicion
        ->select("materia.nombre_materia","materia.estado_materia"); //Campos a mostrar
        $materia = $materia->get();


        for ($i=0; $i < count($materia); $i++) //Sustituir 1 y 0 por "activo" e "inactivo"
        { 
            if ($materia[$i]->estado_materia == 1) {
                $materia[$i]->estado_materia= "activo";
            }
            else {
                $materia[$i]->estado_materia = "inactivo";
            }
        }


        return response()->json($materia); //Mostrar datos
    }
}
