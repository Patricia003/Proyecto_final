<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

//Tablas involucradas: institucion, municipio, departamento
use DateTime;
use App\Models\InstitucionModels;
use App\Models\MunicipioModels;
use App\Models\Departamento; 


class InstitucionController extends Controller
{
    public function listar(Request $request)
    {
        $institucion = InstitucionModels::where("institucion.estado_institucion", "=", 1); //condición

        $institucion = DB::table('institucion') //Conexión con otras tablas
        ->join('municipio', 'institucion.id_municipio', '=', 'municipio.id_municipio') //relación municipio con tabla institucion
        ->join('departamento', 'municipio.id_departamento', '=', 'departamento.id_departamento') //relación departamento con tabla municipio
        ->select("institucion.nombre_inst","institucion.tipo_institucion", "municipio.nombre_municipio","departamento.nombre_departamento") //Campos a mostrar
        ->get();

        return response()->json($institucion); //Mostrar datos en pantalla
    }
}
